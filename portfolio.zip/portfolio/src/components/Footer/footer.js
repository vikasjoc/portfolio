import React from 'react';
import './footer.css';

const Footer = () => {
    return (
        <footer className='footer'>
            <p>& all Copyright ; 2025 Vikas Joc. All right received.</p>
        </footer>
    );
}

export default Footer